#!/bin/sh
. `dirname $0`/../../func.sh



# check the devices with "media-ctl -p"
IPU0_CSI0_DEVICE_0="/dev/video0"
CAM_DEVICE_0="/dev/v4l-subdev3"
IPU0_CSI0_DEVICE_1="/dev/video5"
CAM_DEVICE_1="/dev/v4l-subdev7"

echo "starting gstreamer with two BAYER Sources ..."
echo "read camera_0 from CSI0 and camera_1 from CSI1 with 2592 x 1944"
echo "write 2560x1944 Pixel and write two mt9p006_col_csix_image.raw"
echo "=============================================================="
echo ""
echo "configure IPU/VPU with media_control"
echo "===================================="

media-ctl -r
media-ctl -V '"mt9p031 2-005d":0[fmt:SGRBG8/2592x1944 (16,54)/2592x1944]'
media-ctl -V '"ipu0-csi0-sd":0[fmt:SGRBG8/2592x1944]'
media-ctl -V '"ipu0-csi0-sd":1[fmt:SGRBG8/2592x1944]'
#media-ctl -l '2:0 -> 1:0[1], 1:1 -> 2:0[1]'
#           Camera -> IPU0-CSI0-sd -> IPU0-CSI0-video (/dev/videoX)   

media-ctl -V '"mt9p031 2-0048":0[fmt:SGRBG8/2592x1944 (16,54)/2592x1944]'
media-ctl -V '"ipu1-csi1-sd":0[fmt:SGRBG8/2592x1944]'
media-ctl -V '"ipu1-csi1-sd":1[fmt:SGRBG8/2592x1944]'
#media-ctl -l '9:0 -> 8:0[1], 8:1 -> 10:0[1]'
#           Camera -> IPU0-CSI0-sd -> IPU0-CSI0-video (/dev/videoX)   


gst-launch-1.0 \
	v4l2src num-buffers=3 device=$IPU0_CSI0_DEVICE_0 ! \
	i2c addr=0x48 file=`dirname $0`/../../register-settings-mt9p031.txt show=0 dev=$CAM_DEVICE_0 ! \
	video/x-bayer,format=grbg,depth=8,width=2592,height=1944 ! \
	multifilesink location=mt9p006_col_csi0_image.raw
	
gst-launch-1.0 \
	v4l2src num-buffers=3 device=$IPU0_CSI0_DEVICE_1 ! \
	i2c addr=0x5d file=`dirname $0`/../../register-settings-mt9p031.txt show=0 dev=$CAM_DEVICE_1 ! \
	video/x-bayer,format=grbg,depth=8,width=2592,height=1944 ! \
	multifilesink location=mt9p006_col_csi1_image.raw
