#!/bin/sh


echo "This gstreamer version don't supported Y10 format, therefore used we set the SGRBG10 format."
echo "With another programm you can use Y10 format."
echo "For to save an 10 Bit file of an GRAY image. Set the VM-011-COL in bootargs."
echo "Use the \"mt9p006_col_save_raw_full_res_10bit.sh\". The result is an 10-Bit GRAY image."

#. `dirname $0`/../../func.sh

#init_dev
#[ $? -ne 0 ] && exit 1

#guess_param

#echo "starting gstreamer with $CAM_COL_FORMAT Source ..."
#echo "read $SENSOR_RES (offset x,y=$OFFSET_SENSOR) and write to file mt9p031_gray.raw"
#echo "===================================================================================="
#echo ""
#echo "configure IPU/VPU with media_control"
#echo "===================================="

#media-ctl -r
#media-ctl -V ''$CAM_ENTITY_NUMBER'0[fmt:'Y10'/'$SENSOR_RES'('$OFFSET_SENSOR')/'$SENSOR_RES']'
#media-ctl -V '"ipu0-csi0-sd":0[fmt:'Y10'/'$SENSOR_RES']'
#media-ctl -V '"ipu0-csi0-sd":1[fmt:'Y10'/'$SENSOR_RES']'
#media-ctl -l '2:0 -> 1:0[1], 1:1 -> 2:0[1]'
#           Camera -> IPU0-CSI0-sd -> IPU0-CSI0-video (/dev/videoX)

#echo ""
#echo "start gstreamer"
#echo "==============="

#gst-launch-1.0 \
#	v4l2src num-buffers=$NUMBER_OF_PIC device=$IPU0_CSI0_DEVICE ! \
#	i2c file=`dirname $0`/../../register-settings-mt9p031.txt show=0 dev=$CAM_DEVICE ! \
#	video/x-raw,format=GRAY10,depth=10$FRAME_SIZE ! \
#	multifilesink location=mt9p006_gray_10bit.raw
