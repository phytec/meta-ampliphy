********************************************************************
The following Informations are for the PHYTEC BSP PD15.1.0
on phyFLEX-i.MX6, phyCARD-i.MX6 and phyCORE-i.MX6
********************************************************************

This cameras are currently supported:
- USB-CAM-003H (with UVC Firmware update)
- USB-CAM-103H (with UVC Firmware update) (without trigger)
- USB-CAM-051H (with UVC Firmware update)
- USB-CAM-151H (with UVC Firmware update) (without trigger)

The following scripts are available:
- usb_bwcam-fbdev_640x480 'a monochrome live image with a resolution 
of 640x480 is output on the display.
- usb_bwcam-save_jpg_full_res 'a monochrome JPG is saved with full 
resolution.
- usb_bwcam-save_raw_full_res 'a monochrome RAW is saved with full 
resolution.

Please copy all the files in the directory: 
/home/gstreamer_examples/phytec_usb_cam/

*******************************************************************

Note1:

The following cameras are currently not supported:
- USB-CAM-004H (with UVC Firmware update)
- USB CAM 104H (with UVC Firmware update)
- USB-CAM-052H (with UVC Firmware update)
- USB CAM 152H (with UVC Firmware update)

If support is required, the following patches must be activated:
- Other-bayer.patch and v4l raw.patch for gst-plugins-good 00:10:30

A perfect use of the GStreamer with these cameras is not yet given.
For this purpose you must use other software or custom scripts.

Note2:

The UVC Firmware update can do only by PHYTEC at the moment.

********************************************************************

v4l2-ctl:

v4l2-ctl can be used to change the gain or the exposure time.

Use the following command to get an overview of the available 
functions:
- v4l2-ctl -d /dev/video[x] -L

To change some paramters the following commands can be used:
- v4l2-ctl -d /dev/video[x] -c gain=xx	(xx=16-63)
- v4l2-ctl -d /dev/video[x] -c exposure_absolute=xx (xx=1-2500) 


Note: The driver must be loaded.

********************************************************************