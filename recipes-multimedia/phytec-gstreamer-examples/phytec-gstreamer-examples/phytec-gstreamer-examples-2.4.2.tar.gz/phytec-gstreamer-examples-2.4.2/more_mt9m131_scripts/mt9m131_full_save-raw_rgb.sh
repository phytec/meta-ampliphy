#!/bin/sh


. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo "starting gstreamer with rgb Source ..."
echo "read 1280x1024 and write to file mt9m131_rgb.raw"
echo "================================================"

gst-launch-0.10 \
	v4l2src num-buffers=$NUMBER_OF_PIC device=$DEVICE ! \
	i2c file=`dirname $0`/../register-settings-mt9m131.txt show=0 dev=$DEVICE ! \
	video/x-raw-rgb,width=1280,height=1024 ! \
	multifilesink location=mt9m131_rgb.raw 2>/dev/null

echo "File \"mt9m131_rgb.raw\" (format=rgb[5:6:5], 1280x1024 Pixel)"