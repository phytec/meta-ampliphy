#!/bin/sh


. `dirname $0`/../../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo "starting gstreamer with yuv Source ..."
echo "read 640x480 (scaled in sensor) write to framebuffer 640x480"
echo "============================================================"

gst-launch-0.10 \
	v4l2src device=$DEVICE ! \
	i2c file=`dirname $0`/../../$REG_SET_FILE show=0 dev=$DEVICE ! \
	video/x-raw-yuv,width=640,height=480 ! \
	ffmpegcolorspace ! \
	fbdevsink 2>/dev/null
