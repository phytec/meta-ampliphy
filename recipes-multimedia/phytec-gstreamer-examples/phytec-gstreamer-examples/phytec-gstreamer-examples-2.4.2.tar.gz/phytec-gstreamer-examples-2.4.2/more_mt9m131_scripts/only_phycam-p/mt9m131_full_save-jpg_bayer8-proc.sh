#!/bin/sh
# deactivate automatic gstreamer raw bayer converter
export X_PHYTEC_GSTV4L_RAW=1
. `dirname $0`/../../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo "starting gstreamer with bayer-8 proc Source ..."
echo "read 1280x1024 convert bayer2rgb encode2jpeg and write to file mt9m131_bayer8.jpg"
echo "================================================================================="

gst-launch-0.10 \
	v4l2src num-buffers=$NUMBER_OF_PIC device=$DEVICE ! \
	i2c file=`dirname $0`/../../$REG_SET_FILE show=0 dev=$DEVICE ! \
	video/x-raw-bayer,format=grbg,depth=8,width=1280,height=1024 ! \
	bayer2rgb ! \
	jpegenc ! \
	multifilesink location=mt9m131_bayer8.jpg
