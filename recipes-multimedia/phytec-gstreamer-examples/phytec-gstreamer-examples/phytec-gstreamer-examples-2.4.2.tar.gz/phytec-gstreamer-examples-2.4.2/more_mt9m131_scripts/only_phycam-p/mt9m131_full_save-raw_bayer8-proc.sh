#!/bin/sh


. `dirname $0`/../../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo "starting gstreamer with bayer-8 proc Source ..."
echo "read 1280x1024 and write to file mt9m131_bayer8.raw"
echo "==================================================="

gst-launch-0.10 \
	v4l2src num-buffers=$NUMBER_OF_PIC device=$DEVICE ! \
	i2c file=`dirname $0`/../../$REG_SET_FILE show=0 dev=$DEVICE ! \
	video/x-raw-bayer,depth=8,width=1280,height=1024 ! \
	multifilesink location=mt9m131_bayer8.raw 2>/dev/null

echo "File \"mt9m131_bayer8.raw\" (format=bayer[GRBG], 1280x1024 Pixel)"