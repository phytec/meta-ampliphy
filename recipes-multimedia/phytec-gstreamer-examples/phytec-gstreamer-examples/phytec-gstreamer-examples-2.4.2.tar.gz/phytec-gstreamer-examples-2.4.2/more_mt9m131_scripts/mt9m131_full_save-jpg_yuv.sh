#!/bin/sh


. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo "starting gstreamer with yuv Source ..."
echo "read 1280x1024 encode2jpeg and write to file mt9m131_yuv.jpg"
echo "============================================================"

gst-launch-0.10 \
	v4l2src num-buffers=$NUMBER_OF_PIC device=$DEVICE ! \
	i2c file=`dirname $0`/../register-settings-mt9m131.txt show=0 dev=$DEVICE ! \
	video/x-raw-yuv,width=1280,height=1024 ! \
	jpegenc ! \
	multifilesink location=mt9m131_yuv.jpg 2>/dev/null
