#!/bin/sh


. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo "starting gstreamer with yuv Source ..."
echo "read 1280x1024 and write scaled to framebuffer 640x480"
echo "======================================================"

gst-launch-0.10 \
	v4l2src device=$DEVICE ! \
	i2c file=`dirname $0`/../register-settings-mt9m131.txt show=0 dev=$DEVICE ! \
	video/x-raw-yuv,width=1280,height=1024 ! \
	videoscale ! \
	video/x-raw-yuv,width=640,height=480 ! \
	ffmpegcolorspace ! \
	fbdevsink 2>/dev/null

return 0
