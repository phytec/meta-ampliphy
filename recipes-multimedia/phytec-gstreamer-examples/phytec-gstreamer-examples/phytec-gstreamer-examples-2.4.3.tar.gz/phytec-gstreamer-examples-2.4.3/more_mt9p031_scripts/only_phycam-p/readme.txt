#  VM-011 12-Bit mode
#  PHYTEC 2016

The 12-bit mode is only testable if:
- set Jumpers on VM-011 board (see VCAM manual L748)
- set jumpers on Baseboard (e.g. phyFLEX Mapper J9/J10)