**********************************************************
The following informations are for the PHYTEC BSP PD15.3.0
/ phyFLEX-i.MX6 / phyCARD-i.MX6 / phyCORE-i.MX6
**********************************************************

The following phytec cameras are currently supported:
(depend on hardware interface phyCAM-P and/or phyCAM-S+ on board)
- VM-006 (@43,2MHz use "master-clock_vm006_vm009.sh")		
- VM-006-LVDS (@36MHz use "master-clock_vm006_vm009.sh")
- VM-009 (@54MHz use "master-clock_vm006_vm009.sh")		
- VM-009-LVDS (@36MHz use "master-clock_vm006_vm009.sh")
- VM-010-BW (@27MHz)
- VM-010-COL (@27MHz)
- VM-010-BW-LVDS (@27MHz)
- VM-010-COL-LVDS (@27MHz)
- VM-011-BW (@54MHz)
- VM-011-COL (@54MHz)
- VM-011-BW-LVDS (@54MHz)
- VM-011-COL-LVDS (@54MHz)

For USB-cameras look into "\phytec_usb_cam\..." path.

Additional phytec camera support is in progress.

Please pay attention to the maximum allowable frequencies.
Please read the the Manual L-740 "phyCAM-P / phyCAM-S".


********************************************************************
camera configuration
********************************************************************

The right camera-interface-type, camera-type and camera-address must
be set, by bootarg in the config-file (/env/config-expansions).
See "camera_select_i.MX6.txt".


camera typ (defaults)
=====================
phyFLEX (KIT):
- of_camera_selection -p 0 -b phyCAM-P -a 0x48 VM-011-COL

SUBRA (KIT):
- of_camera_selection -p 0 -b phyCAM-S+ -a 0x48 VM-010-COL

phyCARD (Kit):
- of_camera_selection -p 0 -b phyCAM-S+ -a 0x48 VM-010-BW

phyCORE (Kit):
- of_camera_selection -p 0 -b phyCAM-S+ -a 0x48 VM-010-BW

set new camera i2c adress or new camera typ
===========================================
For use the camera with more i2c adress or added a new camera, you have to compile the image new.
See instruction manual for YOCTO-BSPs.


***************************
First Steps
***************************
1) Disable QT-Demo (only at first start necessary).
   - after login
   - change in the directory  /gstreamer_examples/.. -> cd gstreamer_examples <ENTER>
   - start remove_qt_demo -> ./remove_qt_demo <ENTER>
   - start reboot -> reboot <ENTER>


2) Start gstreamer Demos
   - after login
   - change in the directory  /gstreamer_examples/.. -> cd gstreamer_examples <ENTER>
   - start "bwcam-fbdev_640x480.sh" or "colcam-fbdev_640x480.sh" (depend on your camera type)
   - for more camera type examples, go in camera sensor type subdirectories
     (VM-006 -> mt9m001, VM-008 -> tw9910, VM-009 -> mt9m131, VM-010 -> mt9v024, VM-011 -> mt9p031)

For more informations see link "ftp://ftp.phytec.de/pub/ImageProcessing/"