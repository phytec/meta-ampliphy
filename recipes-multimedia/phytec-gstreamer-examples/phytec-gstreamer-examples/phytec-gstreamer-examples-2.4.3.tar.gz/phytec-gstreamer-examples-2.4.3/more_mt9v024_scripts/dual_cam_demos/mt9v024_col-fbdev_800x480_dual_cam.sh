#!/bin/sh
. `dirname $0`/../../func.sh

echo 0 > /sys/class/graphics/fbcon/cursor_blink

# check the devices with "media-ctl -p"
IPU0_CSI0_DEVICE_0="/dev/video2"
CAM_DEVICE_0="/dev/v4l-subdev3"
IPU0_CSI0_DEVICE_1="/dev/video5"
CAM_DEVICE_1="/dev/v4l-subdev7"

echo "starting gstreamer with two BAYER Sources ..."
echo "read camera_0 from CSI0 and camera_1 from CSI1 with 752 x 480"
echo "scale both streams to 400x255 Pixel and write side by side into same framebuffer"
echo "================================================================================"
echo ""
echo "configure IPU/VPU with media_control"
echo "===================================="

media-ctl -r
media-ctl -V '"mt9v032 2-0048":0[fmt:SGRBG8/752x480 (1,5)/752x480]'
media-ctl -V '"ipu0-csi0-sd":0[fmt:SGRBG8/752x480]'
media-ctl -V '"ipu0-csi0-sd":1[fmt:SGRBG8/752x480]'
#media-ctl -l '2:0 -> 1:0[1], 1:1 -> 2:0[1]'
#           Camera -> IPU0-CSI0-sd -> IPU0-CSI0-video (/dev/videoX)   

media-ctl -V '"mt9v032 2-004c":0[fmt:SGRBG8/752x480 (1,5)/752x480]'
media-ctl -V '"ipu1-csi1-sd":0[fmt:SGRBG8/752x480]'
media-ctl -V '"ipu1-csi1-sd":1[fmt:SGRBG8/752x480]'
#media-ctl -l '9:0 -> 8:0[1], 8:1 -> 10:0[1]'
#           Camera -> IPU0-CSI0-sd -> IPU0-CSI0-video (/dev/videoX)   


echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 videomixer name=mix  sink_0::xpos=0 sink_0::ypos=0 sink_1::xpos=400 sink_1::ypos=0 ! videoconvert ! queue ! fbdevsink sync=false \
   v4l2src device=$IPU0_CSI0_DEVICE_0 ! i2c addr=0x48 file=`dirname $0`/../../register-settings-mt9v02x.txt show=0 dev=$CAM_DEVICE_0 ! \
   video/x-bayer,format=grbg,depth=8,width=752,height=480,framerate=25/1 ! bayer2rgb ! queue ! videoconvert ! video/x-raw,width=752,height=480 ! \
   videoconvert ! videoscale ! video/x-raw,width=400,height=255 ! mix. \
   v4l2src device=$IPU0_CSI0_DEVICE_1 ! i2c addr=0x4c file=`dirname $0`/../../register-settings-mt9v02x.txt show=0 dev=$CAM_DEVICE_1 ! \
   video/x-bayer,format=grbg,depth=8,width=752,height=480,framerate=25/1 ! bayer2rgb ! queue ! videoconvert ! video/x-raw,width=752,height=480 ! \
   videoconvert ! videoscale ! video/x-raw,width=400,height=255 ! mix.


#gst-launch-1.0 \
#	v4l2src device=$IPU0_CSI0_DEVICE_0 ! \
#	i2c addr=0x48 file=`dirname $0`/../../register-settings-mt9v02x.txt show=0 dev=$CAM_DEVICE_0 ! \
#	video/x-bayer,format=grbg,depth=8,width=752,height=480 ! \
#   bayer2rgb ! \
#	videoconvert ! \
#	fbdevsink sync=false
	
#gst-launch-1.0 \
#	v4l2src device=$IPU0_CSI0_DEVICE_1 ! \
#	i2c addr=0x4c file=`dirname $0`/../../register-settings-mt9v02x.txt show=0 dev=$CAM_DEVICE_1 ! \
#	video/x-bayer,format=grbg,depth=8,width=752,height=480 ! \
#   bayer2rgb ! \
#	videoconvert ! \
#	fbdevsink sync=false
	
echo 1 > /sys/class/graphics/fbcon/cursor_blink
