#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param



echo "=============================================================================="
echo "starting gstreamer with $COL_FORMAT Source ..."
echo "read $GRAB_RES, convert bayer2rgb, use i.MX6 vpu mpeg-4/H264 codec and write in capture.mkv"
echo "========================================================================================="
echo ""
echo "configure IPU1_CSI0 (camera_0 port) with media_control"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu1_csi0_mux":1[1]'
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:Y8/'$GRAB_RES' ('$OFFSET_SENSOR')/'$SENSOR_RES_LIVE_DEMO']'
media-ctl -V '"ipu1_csi0_mux":2 [fmt:Y8/'$GRAB_RES']'
media-ctl -V '"ipu1_csi0":2 [fmt:Y8/'$GRAB_RES']'

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

$V4L2_CTRL_CAM0

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 \
	v4l2src device=$IPU1_CSI0_DEVICE $NORM ! \
	video/x-raw,format=GRAY8,depth=8$FRAME_SIZE_LIVE_DEMO$REMAPPER ! \
	videoconvert ! queue ! v4l2h264enc ! h264parse ! matroskamux ! \
	filesink location=capture.mkv

#	i2c file=`dirname $0`/../register-settings-mt9p031.txt show=0 dev=$CAM_DEVICE ! \