#!/bin/sh

echo 0 > /sys/class/graphics/fbcon/cursor_blink

gst-launch-1.0 udpsrc port=5200 \
   ! application/x-rtp,encoding-name=H264,payload=26 \
   ! rtph264depay \
   ! decodebin \
   ! videoconvert \
   ! videoscale \
   ! fbdevsink sync=false
#   ! queue ! kmssink driver-name="imx-drm" scale=false sync=false
 

 
 echo 1 > /sys/class/graphics/fbcon/cursor_blink

