#!/bin/sh

echo 0 > /sys/class/graphics/fbcon/cursor_blink

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="
echo ""
echo "please generate first the file with col_save_h264.sh or bw_save_h264.sh"
echo "======================================================================="


gst-launch-1.0 \
	filesrc location=capture.mkv ! \
	matroskademux ! \
	h264parse ! \
	v4l2h264dec ! \
	videoconvert ! \
	queue ! kmssink driver-name="imx-drm" force-modesetting=false can-scale=false sync=true
#	fbdevsink


echo 1 > /sys/class/graphics/fbcon/cursor_blink