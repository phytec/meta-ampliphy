************************************************************
The i.MX6 networkstream examples are for PHYTEC BSP PD18.x.x
/ phyFLEX-i.MX6 / phyCARD-i.MX6 / phyCORE-i.MX6
************************************************************

Move the script "colcam_network_stream.sh" / "bwcam_network_stream.sh"
into the path "../gstreamer_examples/". Set the attributes of the files.

Attention: Before start the script, set the right IP address for your Host!

Start the script on i.MX6 board.


*******************
show stream on host
*******************

Option 1): Playback with VLC (see http://stackoverflow.com/questions/13154983/gstreamer-rtp-stream-to-vlc)
Generate an sdp-file (Session Description Protocol) for the VLC player.
With following content (Note: Set the right IP address for your Slave):
-------------
v=0
m=video 5200 RTP/AVP 96
c=IN IP4 192.168.3.11
a=rtpmap:96 H264/90000
-------------
Or use the ready "VLC_Network_Stream.sdp" File.
Note: Set the right IP address for your Slave.
For reduced the latency with VLC, read "VLC_Setup.txt".


Option 2): Playback with Gstreamer (Much smaller latency than VLC)
-------------
host$ gst-launch-1.0 udpsrc port=5200 \
   ! application/x-rtp,encoding-name=H264,payload=26 \
   ! rtph264depay \
   ! decodebin \
   ! videoconvert \
   ! videoscale \
   ! ximagesink
-------------

==============================================================
*****************
trouble-shooting:
*****************

1) Firewall:
The stream is not showing.
Please check your firewall setup.

2) Gstreamer cache:
If some plugins are not shown in the output of gst-inspect-1.0, you can clear the gstreamer cache. 
- rm $HOME/.cache/gstreamer-1.0/registry*
- gst-inspect-1.0

http://gstreamer-devel.966125.n4.nabble.com/How-to-build-v4l2videodec-td4669823.html2
"Note that sometimes, cleaning registry may be needed (in case driver has
been loaded after GStreamer had generated it's cache, and without v4l2
plugin file being updated or touched). You can remove the cache by
simply doing "rm $HOME/.cache/gstreamer-1.0/registry*"