#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo 0 > /sys/class/graphics/fbcon/cursor_blink

echo "starting gstreamer with Bayer Source ..."
echo "read 752x480 (offset x,y=1,5) and write to framebuffer 752x480"
echo "=============================================================================="
echo ""
echo "configure IPU1_CSI0 (camera_0 port) with media_control"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu1_csi0_mux":1[1]'
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:SGRBG8_1X8/752x480 (1,5)/752x480]'
media-ctl -V "'ipu1_csi0_mux':2 [fmt:SGRBG8_1X8/752x480]"
media-ctl -V "'ipu1_csi0':2 [fmt:SGRBG8_1X8/752x480]"

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

v4l2-ctl -d $IPU1_CSI0_DEVICE -c row_noise_correction=1

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 \
	v4l2src device=$IPU1_CSI0_DEVICE ! \
	video/x-bayer,format=grbg,depth=8,width=752,height=480 ! \
	bayer2rgbneon ! \
	queue ! kmssink driver-name="imx-drm" force-modesetting=false sync=true
#	fbdevsink sync=true

#	i2c file=`dirname $0`/../register-settings-mt9v02x.txt show=0 dev=$CAM_DEVICE ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.

echo 1 > /sys/class/graphics/fbcon/cursor_blink