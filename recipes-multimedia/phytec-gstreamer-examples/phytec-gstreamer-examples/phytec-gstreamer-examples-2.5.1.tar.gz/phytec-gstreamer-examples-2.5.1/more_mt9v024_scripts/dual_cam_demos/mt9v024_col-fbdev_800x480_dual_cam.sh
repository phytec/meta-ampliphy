#!/bin/sh

echo 0 > /sys/class/graphics/fbcon/cursor_blink

# check the set addresses in config-expansions file
CAM_I2C_ADRESS_0=$(media-ctl -p | grep -B 7 "> \"ipu1_csi0_mux\"" | grep mt9v032 | cut -c25-26)
CAM_I2C_ADRESS_1=$(media-ctl -p | grep -B 7 "> \"ipu2_csi1_mux\"" | grep mt9v032 | cut -c25-26)
CAM_I2C_BUS=$(find /sys/bus/i2c/drivers/mt9v032/ -name "?-00*" | cut -d / -f 7 | cut -c1-1 | sed 2d)

echo ""
echo " camera0 i2c address = $CAM_I2C_ADRESS_0"
echo " camera1 i2c address = $CAM_I2C_ADRESS_1"
echo " i2c bus address = $CAM_I2C_BUS"

# check the devices with "media-ctl -p"
IPU1_CSI0_DEVICE=$(media-ctl -e "ipu1_csi0 capture")
IPU2_CSI1_DEVICE=$(media-ctl -e "ipu2_csi1 capture")
CAM_DEVICE_0=$(media-ctl -e "mt9v032 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_0")
CAM_DEVICE_1=$(media-ctl -e "mt9v032 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_1")

echo " ipu1_csi0 capture device name = $IPU1_CSI0_DEVICE"
echo " ipu2_csi1 capture device name = $IPU2_CSI1_DEVICE"
echo " camera0 subdevice name = $CAM_DEVICE_0"
echo " camera1 subdevice name = $CAM_DEVICE_1"
echo ""
echo "starting gstreamer with two BAYER Sources ..."
echo "read camera_0 from IPU1_CSI0 and camera_1 from IPU2_CSI1 with 640 x 480"
echo "scale both streams to 400x300 Pixel and write side by side into same framebuffer"
echo "================================================================================"
echo ""
echo "configure IPU1_CSI0 and IPU2_CSI1 with media_control"
echo "===================================================="

media-ctl -r
media-ctl -l "'mt9v032 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_0':0->'ipu1_csi0_mux':1[1]"
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V "'mt9v032 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_0':0 [fmt:SGRBG8_1X8/752x480 (55,5)/640x480]"
media-ctl -V "'ipu1_csi0_mux':2 [fmt:SGRBG8_1X8/640x480]"
media-ctl -V "'ipu1_csi0':2 [fmt:SGRBG8_1X8/640x480]"

media-ctl -l "'mt9v032 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_1':0->'ipu2_csi1_mux':1[1]"
media-ctl -l "'ipu2_csi1_mux':2->'ipu2_csi1':0[1]"
media-ctl -l "'ipu2_csi1':2->'ipu2_csi1 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V "'mt9v032 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_1':0 [fmt:SGRBG8_1X8/752x480 (55,5)/640x480]"
media-ctl -V "'ipu2_csi1_mux':2 [fmt:SGRBG8_1X8/640x480]"
media-ctl -V "'ipu2_csi1':2 [fmt:SGRBG8_1X8/640x480]"

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

v4l2-ctl -d $IPU1_CSI0_DEVICE -c row_noise_correction=1
v4l2-ctl -d $IPU2_CSI1_DEVICE -c row_noise_correction=1

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 videomixer name=mix  sink_0::xpos=0 sink_0::ypos=0 sink_1::xpos=400 sink_1::ypos=0 ! videoconvert ! queue ! fbdevsink sync=false \
	v4l2src device=$IPU1_CSI0_DEVICE ! \
	video/x-bayer,format=grbg,depth=8,width=640,height=480,framerate=25/1 ! bayer2rgbneon ! queue ! videoconvert ! video/x-raw,width=640,height=480 ! \
	videoconvert ! videoscale ! video/x-raw,width=400,height=300 ! mix. \
	v4l2src device=$IPU2_CSI1_DEVICE ! \
	video/x-bayer,format=grbg,depth=8,width=640,height=480,framerate=25/1 ! bayer2rgbneon ! queue ! videoconvert ! video/x-raw,width=640,height=480 ! \
	videoconvert ! videoscale ! video/x-raw,width=400,height=300 ! mix.

#gst-launch-1.0 videomixer name=mix  sink_0::xpos=0 sink_0::ypos=0 sink_1::xpos=400 sink_1::ypos=0 ! videoconvert ! queue ! fbdevsink sync=false \
#	v4l2src device=$IPU1_CSI0_DEVICE ! i2c addr=0x48 file=`dirname $0`/../../register-settings-mt9v02x.txt show=0 dev=$CAM_DEVICE_0 ! \
#	video/x-bayer,format=grbg,depth=8,width=640,height=480,framerate=25/1 ! bayer2rgb ! queue ! videoconvert ! video/x-raw,width=752,height=480 ! \
#	videoconvert ! videoscale ! video/x-raw,width=400,height=300 ! mix. \
#	v4l2src device=$IPU2_CSI1_DEVICE ! i2c addr=0x4c file=`dirname $0`/../../register-settings-mt9v02x.txt show=0 dev=$CAM_DEVICE_1 ! \
#	video/x-bayer,format=grbg,depth=8,width=640,height=480,framerate=25/1 ! bayer2rgb ! queue ! videoconvert ! video/x-raw,width=752,height=480 ! \
#	videoconvert ! videoscale ! video/x-raw,width=400,height=300 ! mix.


#gst-launch-1.0 \
#	v4l2src device=$IPU1_CSI0_DEVICE ! \
#	video/x-bayer,format=grbg,depth=8,width=640,height=480 ! \
#	bayer2rgbneon ! \
#	videoconvert ! \
#	fbdevsink sync=true

#	i2c addr=0x48 file=`dirname $0`/../../register-settings-mt9v02x.txt show=0 dev=$CAM_DEVICE_0 ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.
	
#gst-launch-1.0 \
#	v4l2src device=$IPU2_CSI1_DEVICE ! \
#	video/x-bayer,format=grbg,depth=8,width=640,height=480 ! \
#	bayer2rgbneon ! \
#	videoconvert ! \
#	fbdevsink sync=true

#	i2c addr=0x4c file=`dirname $0`/../../register-settings-mt9v02x.txt show=0 dev=$CAM_DEVICE_1 ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.
	
echo 1 > /sys/class/graphics/fbcon/cursor_blink
