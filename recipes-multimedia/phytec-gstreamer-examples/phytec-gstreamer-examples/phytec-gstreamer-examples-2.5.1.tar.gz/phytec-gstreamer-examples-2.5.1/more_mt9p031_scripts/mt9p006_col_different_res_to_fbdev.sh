#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo 0 > /sys/class/graphics/fbcon/cursor_blink

echo "select resolution"
echo "================="
echo "1 = 2592 x 1944 Full"
echo "2 = 2048 x 1536 QXGA"
echo "3 = 1600 x 1200 UXGA"
echo "4 = 1280 x 1024 SXGA"
echo "5 = 1024 x 768  XGA"
echo "6 = 800  x 600  SVGA"
echo "7 = 640  x 480  VGA"
echo "8 = 1920 x 1080 FullHD"
echo "9 = 1280 x 720  HD"
read RESOLUTION
echo "Your select = $RESOLUTION"
case $RESOLUTION in
  "1") SENSOR_RES_LIVE_DEMO="2592x1944"; GRAB_RES="2592x1944"; FRAME_SIZE=",width=2592,height=1944"; OFFSET_SENSOR="16,54"; SCALE_SIZE=",width=640,height=480"; KMS_SYNC="false";;
  "2") SENSOR_RES_LIVE_DEMO="2048x1536"; GRAB_RES="2048x1536"; FRAME_SIZE=",width=2048,height=1536"; OFFSET_SENSOR="288,258"; SCALE_SIZE=",width=640,height=480"; KMS_SYNC="false" ;;
  "3") SENSOR_RES_LIVE_DEMO="1600x1200"; GRAB_RES="1600x1200"; FRAME_SIZE=",width=1600,height=1200"; OFFSET_SENSOR="512,426"; SCALE_SIZE=",width=640,height=480"; KMS_SYNC="false" ;;
  "4") SENSOR_RES_LIVE_DEMO="1280x1024"; GRAB_RES="1280x1024"; FRAME_SIZE=",width=1280,height=1024"; OFFSET_SENSOR="672,514"; SCALE_SIZE=",width=600,height=480"; KMS_SYNC="false" ;;
  "5") SENSOR_RES_LIVE_DEMO="2048x1536"; GRAB_RES="1024x768"; FRAME_SIZE=",width=1024,height=768"; OFFSET_SENSOR="288,258"; SCALE_SIZE=",width=640,height=480"; KMS_SYNC="true" ;;
  "6") SENSOR_RES_LIVE_DEMO="1600x1200"; GRAB_RES="800x600"; FRAME_SIZE=",width=800,height=600"; OFFSET_SENSOR="512,426"; SCALE_SIZE=",width=640,height=480"; KMS_SYNC="true" ;;
  "7") SENSOR_RES_LIVE_DEMO="2560x1920"; GRAB_RES="640x480"; FRAME_SIZE=",width=640,height=480"; OFFSET_SENSOR="32,66"; SCALE_SIZE=",width=640,height=480"; KMS_SYNC="true" ;;
  "8") SENSOR_RES_LIVE_DEMO="1920x1080"; GRAB_RES="1920x1080"; FRAME_SIZE=",width=1920,height=1080"; OFFSET_SENSOR="352,486"; SCALE_SIZE=",width=800,height=450"; KMS_SYNC="false" ;;
  "9") SENSOR_RES_LIVE_DEMO="2560x1440"; GRAB_RES="1280x720"; FRAME_SIZE=",width=1280,height=720"; OFFSET_SENSOR="32,306"; SCALE_SIZE=",width=800,height=450"; KMS_SYNC="false" ;;
  *) SENSOR_RES_LIVE_DEMO="2592x1944"; GRAB_RES="2592x1944"; FRAME_SIZE=",width=2592,height=1944"; OFFSET_SENSOR="16,54"; SCALE_SIZE=",width=640,height=480"; KMS_SYNC="true" ;;
esac

echo "starting gstreamer with $CAM_COL_FMT Source ..."
echo "read $FRAME_SIZE (offset x,y=$OFFSET_SENSOR) convert bayer2rgb and write scaled to framebuffer $SCALE_SIZE"
echo "==============================================================================="
echo ""
echo "configure IPU1_CSI0 (camera_0 port) with media_control"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu1_csi0_mux":1[1]'
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:'$CAM_COL_FMT'/'$GRAB_RES' ('$OFFSET_SENSOR')/'$SENSOR_RES_LIVE_DEMO']'
media-ctl -V '"ipu1_csi0_mux":2 [fmt:'$CAM_COL_FMT'/'$GRAB_RES']'
media-ctl -V '"ipu1_csi0":2 [fmt:'$CAM_COL_FMT'/'$GRAB_RES']'

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

v4l2-ctl -d $IPU1_CSI0_DEVICE -c exposure=480
v4l2-ctl -d $IPU1_CSI0_DEVICE -c gain=32

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 \
	v4l2src device=$IPU1_CSI0_DEVICE ! \
	video/x-$COL_FORMAT$FRAME_SIZE ! \
	bayer2rgbneon ! \
	video/x-raw$FRAME_SIZE ! \
	videoscale ! \
	video/x-raw$SCALE_SIZE ! \
	queue ! kmssink driver-name="imx-drm" force-modesetting=false can-scale=false sync=$KMS_SYNC
#	fbdevsink sync=true

#	i2c file=`dirname $0`/../register-settings-mt9p031.txt show=0 dev=$CAM_DEVICE ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.
	
echo 1 > /sys/class/graphics/fbcon/cursor_blink