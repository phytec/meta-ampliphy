#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param



echo "starting gstreamer with yuv Source ..."
echo "read 1280x1024 encode2jpeg and write to file mt9m131_yuv.jpg"
echo "============================================================"
echo ""
echo "configure IPU1_CSI0 (camera_0 port) with media_control"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu1_csi0_mux":1[1]'
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:YUYV8_2X8/1280x1024@1/15 (26,8)/1280x1024]'
media-ctl -V "'ipu1_csi0_mux':2 [fmt:YUYV8_2X8/1280x1024]"
media-ctl -V "'ipu1_csi0':2 [fmt:YUYV8_2X8/1280x1024@1/15]"

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

v4l2-ctl -d 4 -c auto_exposure=1

echo ""
echo "start gstreamer"
echo "==============="

gst-launch-1.0 \
	v4l2src num-buffers=$NUMBER_OF_PIC device=$IPU1_CSI0_DEVICE ! \
	video/x-raw,format=UYVY,width=1280,height=1024 ! \
	jpegenc ! \
	multifilesink location=mt9m131_yuv.jpg

#	i2c file=`dirname $0`/../register-settings-mt9m131.txt show=0 dev=$CAM_DEVICE ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.


