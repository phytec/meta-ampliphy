#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo 0 > /sys/class/graphics/fbcon/cursor_blink

echo "select resolution"
echo "================="
echo "1 = 1280 x 1024 Fullframe"
echo "2 = 640 x 480 VGA with sensor-skip-mode(skip 640x512, set via @1/30 parameter )"
echo "3 = 800 x 480 WVGA with sensor-roi-mode (offset via media-ctl crop-parameter)"
read RESOLUTION
echo "Your select = $RESOLUTION"
case $RESOLUTION in
  "1") SENSOR_RES_LIVE_DEMO="1280x1024";GRAB_RES="1280x1024"; SKIP="@1/15"; FRAME_SIZE=",width=1280,height=1024"; SCALE_SIZE=",width=600,height=480"; OFFSET_SENSOR="26,8"; SUBSAMPLING="0"; KMS_SYNC="true" ;;
  "2") SENSOR_RES_LIVE_DEMO="1280x1024";GRAB_RES="640x512"; SKIP="@1/30"; FRAME_SIZE=",width=640,height=512"; SCALE_SIZE=",width=640,height=480"; OFFSET_SENSOR="26,8"; SUBSAMPLING="1"; KMS_SYNC="true" ;;
  "3") SENSOR_RES_LIVE_DEMO="800x480";GRAB_RES="800x480"; SKIP="@1/15"; FRAME_SIZE=",width=800,height=480"; SCALE_SIZE=",width=800,height=480"; OFFSET_SENSOR="266,280"; SUBSAMPLING="0"; KMS_SYNC="true" ;;
  *) SENSOR_RES_LIVE_DEMO="1280x1024";GRAB_RES="1280x1024"; SKIP="@1/15"; FRAME_SIZE=",width=1280,height=1024"; SCALE_SIZE=",width=640,height=480"; OFFSET_SENSOR="26,8"; SUBSAMPLING="0"; KMS_SYNC="true" ;;
esac

echo "starting gstreamer with YUV Source ..."
echo "read $FRAME_SIZE (offset x,y=$OFFSET_SENSOR) and write scaled to framebuffer $SCALE_SIZE"
echo "=============================================================="
echo ""
echo "configure IPU1_CSI0 (camera_0 port) with media_control"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu1_csi0_mux":1[1]'
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:YUYV8_2X8/'$GRAB_RES''$SKIP' crop:('$OFFSET_SENSOR')/'$SENSOR_RES_LIVE_DEMO']'
media-ctl -V '"ipu1_csi0_mux":2 [fmt:YUYV8_2X8/'$GRAB_RES']'
media-ctl -V '"ipu1_csi0":2 [fmt:YUYV8_2X8/'$GRAB_RES''$SKIP']'

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

v4l2-ctl -d 4 -c auto_exposure=1

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 \
	v4l2src device=$IPU1_CSI0_DEVICE ! \
	video/x-raw,format=UYVY$FRAME_SIZE ! \
	videoscale ! \
	video/x-raw$SCALE_SIZE ! \
	queue ! kmssink driver-name="imx-drm" force-modesetting=false can-scale=false sync=$KMS_SYNC
#	fbdevsink sync=false

#	i2c file=`dirname $0`/../register-settings-mt9m131.txt show=0 dev=$CAM_DEVICE ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.
	
echo 1 > /sys/class/graphics/fbcon/cursor_blink
