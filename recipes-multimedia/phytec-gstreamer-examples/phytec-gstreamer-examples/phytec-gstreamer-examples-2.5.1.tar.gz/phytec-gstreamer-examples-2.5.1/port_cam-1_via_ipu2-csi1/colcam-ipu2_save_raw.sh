#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param



echo "starting gstreamer with COLOR (BAYER, YUV or RGB depend of camera typ) Source ..."
echo "read $SENSOR_RES (offset x,y=$OFFSET_SENSOR), convert and write to col_camera.raw"
echo "=============================================================================="
echo ""
echo "configure IPU2_CSI1 (camera_1 port) with media_control"
echo "camera_0 port must be disabled"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu2_csi1_mux":1[1]'
media-ctl -l "'ipu2_csi1_mux':2->'ipu2_csi1':0[1]"
media-ctl -l "'ipu2_csi1':2->'ipu2_csi1 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:'$CAM_COL_FMT'/'$SENSOR_RES' ('$OFFSET_SENSOR')/'$SENSOR_RES']'
media-ctl -V '"ipu2_csi1_mux":2 [fmt:'$CAM_COL_FMT'/'$SENSOR_RES']'
media-ctl -V '"ipu2_csi1":2 [fmt:'$CAM_COL_FMT'/'$SENSOR_RES']'

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

$V4L2_CTRL_CAM1

echo ""
echo "start gstreamer"
echo "==============="

gst-launch-1.0 \
	v4l2src num-buffers=$NUMBER_OF_PIC device=$IPU2_CSI1_DEVICE $NORM ! \
	video/x-$COL_FORMAT$FRAME_SIZE$REMAPPER ! \
	multifilesink location=col_$CAMERA.raw

#	i2c file=`dirname $0`/../$REG_SET_FILE show=0 dev=$CAM_DEVICE ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.

echo "File \"col_$CAMERA.raw\" ($COL_FORMAT$FRAME_SIZE)"