#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo 0 > /sys/class/graphics/fbcon/cursor_blink

echo "starting gstreamer with GRAY Source ..."
echo "read $GRAB_RES (offset x,y=$OFFSET_SENSOR), and write to framebuffer 640x480"
echo "======================================================================="
echo ""
echo "configure IPU2_CSI1 (camera_1 port) with media_control"
echo "camera_0 port must be disabled"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu2_csi1_mux":1[1]'
media-ctl -l "'ipu2_csi1_mux':2->'ipu2_csi1':0[1]"
media-ctl -l "'ipu2_csi1':2->'ipu2_csi1 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:'$CAM_BW_FMT'/'$GRAB_RES' ('$OFFSET_SENSOR')/'$SENSOR_RES_LIVE_DEMO']'
media-ctl -V '"ipu2_csi1_mux":2 [fmt:'$CAM_BW_FMT'/'$GRAB_RES']'
media-ctl -V '"ipu2_csi1":2 [fmt:'$CAM_BW_FMT'/'$GRAB_RES']'

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

$V4L2_CTRL_CAM1

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 \
	v4l2src device=$IPU2_CSI1_DEVICE $NORM ! \
	video/x-raw,format=GRAY8,depth=8$FRAME_SIZE_LIVE_DEMO$REMAPPER ! \
	videoconvert ! video/x-raw$FRAME_SIZE_LIVE_DEMO ! \
	videoscale ! video/x-raw,format=GRAY8,width=640,height=480 ! \
	videoconvert ! \
	queue ! kmssink driver-name="imx-drm" force-modesetting=false can-scale=false sync=true
#	fbdevsink sync=false

#	i2c file=`dirname $0`/../$REG_SET_FILE show=0 dev=$CAM_DEVICE ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.

	
echo 1 > /sys/class/graphics/fbcon/cursor_blink