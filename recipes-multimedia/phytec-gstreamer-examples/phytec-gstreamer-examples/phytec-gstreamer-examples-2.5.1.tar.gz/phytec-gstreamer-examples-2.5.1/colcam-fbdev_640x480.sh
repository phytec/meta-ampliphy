#!/bin/sh
. `dirname $0`/func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo 0 > /sys/class/graphics/fbcon/cursor_blink

echo "starting gstreamer with COLOR (BAYER, YUV or RGB depend of camera typ) Source ..."
echo "read $GRAB_RES (offset x,y=$OFFSET_SENSOR), convert and write to framebuffer 640x480"
echo "=============================================================================="
echo ""
echo "configure IPU1_CSI0 (camera_0 port) with media_control"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu1_csi0_mux":1[1]'
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:'$CAM_COL_FMT'/'$GRAB_RES' ('$OFFSET_SENSOR')/'$SENSOR_RES_LIVE_DEMO']'
media-ctl -V '"ipu1_csi0_mux":2 [fmt:'$CAM_COL_FMT'/'$GRAB_RES']'
media-ctl -V '"ipu1_csi0":2 [fmt:'$CAM_COL_FMT'/'$GRAB_RES']'

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

$V4L2_CTRL_CAM0

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 \
	v4l2src device=$IPU1_CSI0_DEVICE $NORM ! \
	video/x-$COL_FORMAT$FRAME_SIZE_LIVE_DEMO$REMAPPER !$BAYER_CONVERT \
	videoconvert ! video/x-raw$FRAME_SIZE_LIVE_DEMO ! \
	videoscale ! video/x-raw,width=640,height=480 ! \
	queue ! kmssink driver-name="imx-drm" force-modesetting=false can-scale=false sync=false
#	fbdevsink sync=false

#	i2c file=$REG_SET_FILE show=0 dev=$CAM_DEVICE ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.

echo 1 > /sys/class/graphics/fbcon/cursor_blink
