**********************************************************
The following informations are for the PHYTEC BSP PD18.1.x
/ phyFLEX-i.MX6 / phyCARD-i.MX6 / phyCORE-i.MX6
**********************************************************

The following phytec cameras are currently supported:
(depend on hardware interface phyCAM-P and/or phyCAM-S+ on board)
#- VM-006 (mt9m001 sensor, @43,2MHz use "master-clock_vm006_vm009.sh")		
#- VM-006-LVDS (mt9m001 sensor, @36MHz use "master-clock_vm006_vm009.sh")
#- VM-008 (tw9910 digitizer, internal master clock)
- VM-009 (mt9m131 sensor, @54MHz)		
- VM-009-LVDS (mt9m131 sensor, @54MHz Note: @36MHz only at PL1339.0 and at phyCAM-S+ use "master-clock_vm006_vm009.sh")
- VM-010-BW (mt9v024 sensor, @27MHz)
- VM-010-COL (mt9v024 sensor, @27MHz)
- VM-010-BW-LVDS (mt9v024 sensor, @27MHz)
- VM-010-COL-LVDS (mt9v024 sensor, @27MHz)
- VM-011-BW (mt9p031 sensor, @54MHz)
- VM-011-COL (mt9p006 sensor, @54MHz, see more_mt9p031_scripts)
- VM-011-BW-LVDS (mt9p031 sensor, @54MHz)
- VM-011-COL-LVDS (mt9p006 sensor, @54MHz, see more_mt9p031_scripts)
- VM-012-BW-LVDS (vita1300 sensor, @54MHz)
- VM-012-COL-LVDS (vita1300 sensor, @54MHz)
- VM-050-x (thermal sensor, internal master clock)
- VM-051-x (thermal sensor, internal master clock)


For USB-cameras look into "\phytec_usb_cam\..." path.

Additional phytec camera support is in progress.

Please pay attention to the maximum allowable frequencies.
Please read the the Manual L-740 "phyCAM-P / phyCAM-S".


********************************************************************
camera configuration
********************************************************************

The right camera-interface-type, camera-type and camera-address must
be set, by bootarg in the config-file (/env/config-expansions).
See "camera_select_i.MX6.txt".


camera typ (defaults)
=====================
phyFLEX (KIT):
- of_camera_selection -p 0 -b phyCAM-P -a 0x48 VM-011-COL

SUBRA (KIT):
- of_camera_selection -p 0 -b phyCAM-S+ -a 0x48 VM-010-COL

phyCARD (Kit):
- of_camera_selection -p 0 -b phyCAM-S+ -a 0x48 VM-010-BW

phyCORE (Kit Mira):
- of_camera_selection -p 0 -b phyCAM-S+ -a 0x48 VM-010-BW

phyCORE (Kit Nunki):
- of_camera_selection -p 0 -b phyCAM-P -a 0x48 VM-010-BW

set new camera i2c adress or new camera typ
===========================================
For use the camera with more i2c adress or added a new camera, you have to compile the image new.
See instruction manual for YOCTO-BSPs.


***************************
First Steps
***************************
1) Disable QT-Demo (only at first start necessary).
   - after login
   - change in the directory  /gstreamer_examples/.. -> cd gstreamer_examples <ENTER>
   - start remove_qt_demo -> ./remove_qt_demo <ENTER>
   - start reboot -> reboot <ENTER>

2) Start gstreamer Demos
   - after login
   - change in the directory  /gstreamer_examples/.. -> cd gstreamer_examples <ENTER>
   - for one camera at camera_0 port (ipu1-csi0):
	 * start "bwcam-fbdev_640x480.sh" or "colcam-fbdev_640x480.sh" (depend on your camera type)
	 * for more camera examples, go in camera sensor type subdirectories
       (VM-006 -> mt9m001, VM-008 -> tw9910, VM-009 -> mt9m131, VM-010 -> mt9v024, VM-011 -> mt9p031)
       (VM-012 -> vita1300)
     * for sample scripts which use the H264 VPU-Codec use scripts in subdirectory .../vpu_enc_dec_scripts/...
   - for one camera at camera_1 port (ipu2-csi1):
     * start scripts in the subdirectory .../port_cam-1_via_ipu2-csi1/...
   - for two cameras, one at camera_0 port (ipu1-csi0) and one camera at camera_1 port (ipu2-csi1):
     * start scripts in the subdirectory .../more_[xxx]/dual_cam_demos/...
   - for thermal cameras VM-050/051 use examples in subdirectory .../phytec_thermal_cam/...)
	
For more informations see link "ftp://ftp.phytec.de/pub/ImageProcessing/"