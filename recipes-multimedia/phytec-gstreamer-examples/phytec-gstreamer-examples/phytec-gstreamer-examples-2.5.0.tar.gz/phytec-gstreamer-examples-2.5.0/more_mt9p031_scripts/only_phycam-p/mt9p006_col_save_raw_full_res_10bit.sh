#!/bin/sh

echo ""
echo "This gstreamer version don't supported Bayer_10 format, therefore use the c-example"
echo "change into path ...\v4l2_c-examples\..."
echo "start file mt9v02x_col_full_save-raw.sh with CAM_COL_FMT=\"SGRBG10_1X10\" directive"
echo ""

#. `dirname $0`/../../func.sh

#init_dev
#[ $? -ne 0 ] && exit 1

#guess_param



#echo "starting gstreamer with $CAM_COL_FORMAT Source ..."
#echo "read $SENSOR_RES (offset x,y=$OFFSET_SENSOR) and write to file mt9p006_bayer_10bit.raw"
#echo "========================================================================================="
#echo ""
#echo "configure IPU1_CSI0 (camera_0 port) with media_control"
#echo "======================================================"

#media-ctl -r
#media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu1_csi0_mux":1[1]'
#media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
#media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

#media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:'SGRBG10_1X10'/'$SENSOR_RES' ('$OFFSET_SENSOR')/'$SENSOR_RES']'
#media-ctl -V '"ipu1_csi0_mux":2 [fmt:'SGRBG10_1X10'/'$SENSOR_RES']'
#media-ctl -V '"ipu1_csi0":2 [fmt:'SGRBG10_1X10'/'$SENSOR_RES']'

#echo ""
#echo " configure camera with v4l2_control"
#echo " =================================="

#v4l2-ctl -d $IPU1_CSI0_DEVICE -c exposure=480
#v4l2-ctl -d $IPU1_CSI0_DEVICE -c gain=32

#echo ""
#echo "start gstreamer"
#echo "==============="

#gst-launch-1.0 \
#	v4l2src num-buffers=$NUMBER_OF_PIC device=$IPU1_CSI0_DEVICE ! \
#	video/x-bayer,format=grbg,depth=10$FRAME_SIZE ! \
#	multifilesink location=mt9p006_bayer_10bit.raw

#	i2c file=`dirname $0`/../../register-settings-mt9p031.txt show=0 dev=$CAM_DEVICE ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.