#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param



echo "starting gstreamer with GRAY Source ..."
echo "read $SENSOR_RES (offset x,y=$OFFSET_SENSOR), encode2jpeg and write to file bw_$CAMERA.jpg"
echo "==========================================================================================="
echo ""
echo "configure IPU1_CSI0 (camera_0 port) with media_control"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu1_csi0_mux":1[1]'
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

v4l2-ctl -d $IPU1_CSI0_DEVICE -c subsampling=$SUBSAMPLING
# Note: Set subsampling is necessary before set resolution

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:Y8/'$SENSOR_RES' crop:('$OFFSET_SENSOR')/'$SENSOR_RES']'
media-ctl -V '"ipu1_csi0_mux":2 [fmt:Y8/'$SENSOR_RES']'
media-ctl -V '"ipu1_csi0":2 [fmt:Y8/'$SENSOR_RES']'

echo ""
echo "start gstreamer"
echo "==============="

gst-launch-1.0 \
	v4l2src num-buffers=$NUMBER_OF_PIC device=$IPU1_CSI0_DEVICE ! \
	i2c file=`dirname $0`/../register-settings-vita1300.txt show=0 dev=$CAM_DEVICE ! \
	video/x-raw,format=GRAY8,depth=8,width=1280,height=1024 ! \
	vita1300_remapper mode=0 passthrough=false ! \
	videoconvert ! \
	jpegenc ! \
	multifilesink location=bw_$CAMERA.jpg