#!/bin/sh



# check the set addresses in config-expansions file
CAM_I2C_ADRESS_0=$(media-ctl -p | grep -B 7 "> \"ipu1_csi0_mux\"" | grep mt9m111 | cut -c25-26)
CAM_I2C_ADRESS_1=$(media-ctl -p | grep -B 7 "> \"ipu2_csi1_mux\"" | grep mt9m111 | cut -c25-26)
CAM_I2C_BUS=$(find /sys/bus/i2c/drivers/mt9m111/ -name "?-00*" | cut -d / -f 7 | cut -c1-1 | sed 2d)

echo ""
echo " camera0 i2c address = $CAM_I2C_ADRESS_0"
echo " camera1 i2c address = $CAM_I2C_ADRESS_1"
echo " i2c bus address = $CAM_I2C_BUS"

# check the devices with "media-ctl -p"
IPU1_CSI0_DEVICE=$(media-ctl -e "ipu1_csi0 capture")
IPU2_CSI1_DEVICE=$(media-ctl -e "ipu2_csi1 capture")
CAM_DEVICE_0=$(media-ctl -e "mt9m111 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_0")
CAM_DEVICE_1=$(media-ctl -e "mt9m111 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_1")

echo " ipu1_csi0 capture device name = $IPU1_CSI0_DEVICE"
echo " ipu2_csi1 capture device name = $IPU2_CSI1_DEVICE"
echo " camera0 subdevice name = $CAM_DEVICE_0"
echo " camera1 subdevice name = $CAM_DEVICE_1"
echo ""
echo "starting gstreamer with two YUV Sources ..."
echo "read camera_0 from IPU1_CSI0 and camera_1 from IPU2_CSI1 with 1280 x 1024"
echo "write side by side to 2560x1024 Pixel, convert to jpg and write to mt9m131_col_dual_image.jpg"
echo "=============================================================================================="
echo ""
echo "configure IPU1_CSI0 and IPU2_CSI1 with media_control"
echo "===================================================="

media-ctl -r
media-ctl -l "'mt9m111 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_0':0->'ipu1_csi0_mux':1[1]"
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V "'mt9m111 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_0':0 [fmt:YUYV8_2X8/1280x1024@1/15 (26,8)/1280x1024]"
media-ctl -V "'ipu1_csi0_mux':2 [fmt:YUYV8_2X8/1280x1024]"
media-ctl -V "'ipu1_csi0':2 [fmt:YUYV8_2X8/1280x1024@1/15]"

media-ctl -l "'mt9m111 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_1':0->'ipu2_csi1_mux':1[1]"
media-ctl -l "'ipu2_csi1_mux':2->'ipu2_csi1':0[1]"
media-ctl -l "'ipu2_csi1':2->'ipu2_csi1 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V "'mt9m111 $CAM_I2C_BUS-00$CAM_I2C_ADRESS_1':0 [fmt:YUYV8_2X8/1280x1024@1/15 (26,8)/1280x1024]"
media-ctl -V "'ipu2_csi1_mux':2 [fmt:YUYV8_2X8/1280x1024]"
media-ctl -V "'ipu2_csi1':2 [fmt:YUYV8_2X8/1280x1024@1/15]"

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

v4l2-ctl -d $IPU1_CSI0_DEVICE -c auto_exposure=0
v4l2-ctl -d $IPU2_CSI1_DEVICE -c auto_exposure=0

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 videomixer name=mix  sink_0::xpos=0 sink_0::ypos=0 sink_1::xpos=1280 sink_1::ypos=0 ! videoconvert ! jpegenc ! multifilesink location=mt9m131_bw_dual_image.jpg \
	v4l2src num-buffers=3 device=$IPU1_CSI0_DEVICE ! \
	video/x-raw,format=UYVY,depth=8,width=1280,height=1024,framerate=15/1 ! \
	mix. \
 	v4l2src num-buffers=3 device=$IPU2_CSI1_DEVICE ! \
	video/x-raw,format=UYVY,depth=8,width=1280,height=1024,framerate=15/1 ! \
	mix. 

#	i2c addr=0x$CAM_I2C_ADRESS_0 file=`dirname $0`/../../register-settings-mt9m131.txt show=0 dev=$CAM_DEVICE_0 ! \


#gst-launch-1.0 \
#	v4l2src device=$IPU1_CSI0_DEVICE ! \
#	video/x-raw,format=UYVY,depth=8,width=640,height=512 ! \
#	videoscale ! video/x-raw,format=UYVY,depth=8,width=640,height=480 ! \
#	videoconvert ! \
#	queue ! kmssink driver-name="imx-drm" force-modesetting=false sync=true
#
#	i2c addr=0x$CAM_I2C_ADRESS_0 file=`dirname $0`/../../register-settings-mt9m131.txt show=0 dev=$CAM_DEVICE_0 ! \

	
#gst-launch-1.0 \
#	v4l2src device=$IPU2_CSI1_DEVICE ! \
#	i2c addr=0x$CAM_I2C_ADRESS_1 file=`dirname $0`/../../register-settings-mt9m131.txt show=0 dev=$CAM_DEVICE_1 ! \
#	video/x-raw,format=UYVY,depth=8,width=640,height=512 ! \
#	videoscale ! video/x-raw,format=UYVY,depth=8,width=640,height=480 ! \
#	videoconvert ! \
#	queue ! kmssink driver-name="imx-drm" force-modesetting=false sync=true
##	fbdevsink sync=false
	

