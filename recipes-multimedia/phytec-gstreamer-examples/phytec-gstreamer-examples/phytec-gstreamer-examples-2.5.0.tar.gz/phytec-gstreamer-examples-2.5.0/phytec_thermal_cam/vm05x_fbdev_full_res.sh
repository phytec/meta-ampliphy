#!/bin/sh

echo 0 > /sys/class/graphics/fbcon/cursor_blink

CAM_BW_FMT=Y8
CAM_DRIVER="vm050"
CAM_ENTITY_NUMBER=`media-ctl -p | grep " $CAM_DRIVER" | awk '{print $4}'`
CAM_I2C_ADRESS=$(find /sys/bus/i2c/drivers/phytec-vm050/ -name "?-00*" | cut -d / -f 7 | cut -c5-6)
CAM_I2C_BUS=$(find /sys/bus/i2c/drivers/phytec-vm050/ -name "?-00*" | cut -d / -f 7 | cut -c1-1)
CAM_DEVICE=$(media-ctl -e "$CAM_DRIVER@$CAM_I2C_ADRESS")
IPU1_CSI0_DEVICE=$(media-ctl -e "ipu1_csi0 capture")
IPU2_CSI1_DEVICE=$(media-ctl -e "ipu2_csi1 capture")
CAMERA_TYP=$(i2cget -y -f $CAM_I2C_BUS 0x$CAM_I2C_ADRESS 0x00 w | cut -c 4)

if [ "$CAMERA_TYP" = "1" ]; then
	CAMERA="VM-050"
	GRAB_RES="32x32"
	FRAME_SIZE=",width=32,height=32"
	FRAME_SCALE_SIZE=",width=320,height=320"
	OFFSET="(0,0)"
elif [ "$CAMERA_TYP" = "2" ]; then
	CAMERA="VM-051"
	GRAB_RES="80x64"
	FRAME_SIZE=",width=80,height=64"
	FRAME_SCALE_SIZE=",width=480,height=384"
	OFFSET="(0,0)"
else
	echo " no camera driver loaded"
	echo " please check camera device tree" 
	echo ""
	return 1
fi

echo ""
echo " found camera = $CAMERA"
echo " camera entity name = $CAM_ENTITY_NUMBER"
echo " camera subdevice name = $CAM_DEVICE"
echo " ipu1_csi0 capture device name = $IPU1_CSI0_DEVICE"
echo " ipu2_csi1 capture device name = $IPU2_CSI1_DEVICE"
echo ""

echo ""
echo " configure IPU1_CSI0 (camera_0 port) with media_control"
echo " ======================================================"

media-ctl -r
media-ctl -l "\"$CAM_ENTITY_NUMBER\":0 -> \"ipu1_csi0_mux\":1 [1]"
media-ctl -l "\"ipu1_csi0_mux\":2 -> \"ipu1_csi0\":0 [1]"
media-ctl -l "\"ipu1_csi0\":2 -> \"ipu1_csi0 capture\":0 [1]"

media-ctl -V "\"$CAM_ENTITY_NUMBER\":0[fmt:$CAM_BW_FMT/$GRAB_RES $OFFSET/$GRAB_RES]"
media-ctl -V "\"ipu1_csi0_mux\":2[fmt:$CAM_BW_FMT/$GRAB_RES field: none]"
media-ctl -V "\"ipu1_csi0\":2[fmt:$CAM_BW_FMT/$GRAB_RES field: none]"

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

v4l2-ctl -d $IPU1_CSI0_DEVICE --set-ctrl=autoscale_mode=1

echo ""
echo " start gstreamer, break with ctl-C"
echo " ================================="

gst-launch-1.0 \
	v4l2src device=$IPU1_CSI0_DEVICE ! \
	video/x-raw,format=GRAY8,depth=8$FRAME_SIZE ! \
	pseudocolor2 mode=table invert=0 ! video/x-raw,format=RGB$FRAME_SIZE ! \
	videoscale ! video/x-raw$FRAME_SCALE_SIZE ! \
	videoconvert ! \
	fbdevsink sync=true
#	queue ! kmssink driver-name="imx-drm" force-modesetting=false can-scale=false sync=true


#	i2c file=register-settings-vm05x.txt show=0 dev=$CAM_DEVICE ! \
#	Use the i2s plugin only for special register settings, that are not available through v4l2_control.

echo 1 > /sys/class/graphics/fbcon/cursor_blink
