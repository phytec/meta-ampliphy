For help of "save_raw_image" type 
> save_raw_image -h


Please use the following scripts for the corresponding phytec camera module:
#VM-006 	= mt9m001_bw_full_save-raw
#VM-008 	= tw9910_col_full_save-raw
VM-009 		= mt9m131_col_full_save-raw.sh
VM-010-BW 	= mt9v02x_bw_full_save-raw.sh
VM-010-COL 	= mt9v02x_col_full_save-raw.sh
VM-011-BW 	= mt9p031_bw_full_save-raw.sh
VM-011-COL 	= mt9p006_col_full_save-raw.sh
#VM-012-BW 	= vita1300_bw_full_save-raw.sh
#VM-012-COL	= vita1300_COL_full_save-raw.sh


#Sourcen are located, in BSP pfad "...git clone git://git.phytec.de/bvtest/...".
#receipts are located, in BSP pfad "...sources/meta-yogurt/recipes-support/bvtest/...".


links of interest:
http://linuxtv.org/downloads/v4l-dvb-apis/v4l2grab-example.html 
http://linuxtv.org/downloads/v4l-dvb-apis/capture-example.html 
help under: 
http://linuxtv.org/downloads/v4l-dvb-apis/ 
