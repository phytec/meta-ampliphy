#!/bin/sh

. /usr/share/phytec-gstreamer-examples/func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo "pixel depth"
echo "================="
echo "1 = 8-Bit"
echo "2 = 10-Bit (only for phyCAM-P)"
echo "3 = 12-Bit (only for phyCAM-P and right camera jumper settings)"
read PIX_DEPTH
echo "Your select = $PIX_DEPTH"
case $PIX_DEPTH in
  "1") CAM_BW_FMT="Y8";;
  "2") CAM_BW_FMT="Y10";;
  "3") CAM_BW_FMT="Y12";;
  *) CAM_BW_FMT="Y8";;
esac

echo ""
echo "configure IPU1_CSI0 (camera_0 port) with media_control"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu1_csi0_mux":1[1]'
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:'$CAM_BW_FMT'/'$SENSOR_RES' ('$OFFSET_SENSOR')/'$SENSOR_RES']'
media-ctl -V '"ipu1_csi0_mux":2 [fmt:'$CAM_BW_FMT'/'$SENSOR_RES']'
media-ctl -V '"ipu1_csi0":2 [fmt:'$CAM_BW_FMT'/'$SENSOR_RES']'

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

v4l2-ctl -d $IPU1_CSI0_DEVICE -c exposure=480
v4l2-ctl -d $IPU1_CSI0_DEVICE -c gain=32

# Additional Settings
COL_FMT=$CAM_BW_FMT
X_RES=${SENSOR_RES%%x*}
Y_RES=${SENSOR_RES##*x}
REG_SET_FILE=/usr/share/phytec-gstreamer-examples/${REG_SET_FILE##*/}


echo "starting save_raw_image with format $COL_FMT"
echo "read $X_RES x $Y_RES and write to RAW-file"
echo "============================================="

save_raw_image -D $IPU1_CSI0_DEVICE -no_subdev  -f $COL_FMT -res_x $X_RES -res_y $Y_RES -d $NUMBER_OF_PIC -n $CAMERA"_PixDepth_"$CAM_BW_FMT"_"
#save_raw_image -D $IPU0_CSI0_DEVICE -no_subdev -f $COL_FMT -res_x $X_RES -res_y $Y_RES -d $NUMBER_OF_PIC -r $REG_SET_FILE -n $CAMERA"_PixDepth_"$CAM_BW_FMT"_"
