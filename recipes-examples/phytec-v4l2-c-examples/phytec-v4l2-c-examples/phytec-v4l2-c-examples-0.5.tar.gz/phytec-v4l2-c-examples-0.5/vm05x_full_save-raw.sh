#!/bin/sh



CAM_BW_FMT=Y8
CAM_DRIVER="vm050"
CAM_ENTITY_NUMBER=`media-ctl -p | grep " $CAM_DRIVER" | awk '{print $4}'`
CAM_I2C_ADRESS=$(find /sys/bus/i2c/drivers/phytec-vm050/ -name "?-00*" | cut -d / -f 7 | cut -c5-6)
CAM_I2C_BUS=$(find /sys/bus/i2c/drivers/phytec-vm050/ -name "?-00*" | cut -d / -f 7 | cut -c1-1)
CAM_DEVICE=$(media-ctl -e "$CAM_DRIVER@$CAM_I2C_ADRESS")
IPU1_CSI0_DEVICE=$(media-ctl -e "ipu1_csi0 capture")
IPU2_CSI1_DEVICE=$(media-ctl -e "ipu2_csi1 capture")
CAMERA_TYP=$(i2cget -y -f $CAM_I2C_BUS 0x$CAM_I2C_ADRESS 0x00 w | cut -c 4)

if [ "$CAMERA_TYP" = "1" ]; then
	CAMERA="VM-050"
	GRAB_RES="32x32"
	OFFSET="(0,0)"
elif [ "$CAMERA_TYP" = "2" ]; then
	CAMERA="VM-051"
	GRAB_RES="80x64"
	OFFSET="(0,0)"
else
	echo " no camera driver loaded"
	echo " please check camera device tree" 
	echo ""
	return 1
fi

echo ""
echo " found camera = $CAMERA"
echo " camera entity name = $CAM_ENTITY_NUMBER"
echo " camera subdevice name = $CAM_DEVICE"
echo " ipu1_csi0 capture device name = $IPU1_CSI0_DEVICE"
echo " ipu2_csi1 capture device name = $IPU2_CSI1_DEVICE"
echo ""

echo "pixel depth"
echo "================="
echo "1 = 8-Bit"
echo "2 = 10-Bit"
echo "3 = 12-Bit"
#echo "4 = 16-Bit (Format: CAM_BW_FMT = Y16_2x8)"
read PIX_DEPTH
echo "Your select = $PIX_DEPTH"
case $PIX_DEPTH in
  "1") CAM_BW_FMT="Y8";;
  "2") CAM_BW_FMT="Y10";;
  "3") CAM_BW_FMT="Y12";;
  *) CAM_BW_FMT="Y8";;
esac

echo ""
echo "configure IPU1_CSI0 (camera_0 port) with media_control"
echo "======================================================"

media-ctl -r
media-ctl -l "\"$CAM_ENTITY_NUMBER\":0 -> \"ipu1_csi0_mux\":1 [1]"
media-ctl -l "\"ipu1_csi0_mux\":2 -> \"ipu1_csi0\":0 [1]"
media-ctl -l "\"ipu1_csi0\":2 -> \"ipu1_csi0 capture\":0 [1]"

media-ctl -V "\"$CAM_ENTITY_NUMBER\":0[fmt:$CAM_BW_FMT/$GRAB_RES $OFFSET/$GRAB_RES]"
media-ctl -V "\"ipu1_csi0_mux\":2[fmt:$CAM_BW_FMT/$GRAB_RES field: none]"
media-ctl -V "\"ipu1_csi0\":2[fmt:$CAM_BW_FMT/$GRAB_RES field: none]"

echo ""
echo " configure camera with v4l2_control"
echo " =================================="

v4l2-ctl -d $IPU1_CSI0_DEVICE --set-ctrl=autoscale_mode=1

# Additional Settings
COL_FMT=$CAM_BW_FMT
X_RES=${GRAB_RES%%x*}
Y_RES=${GRAB_RES##*x}
NUMBER_OF_PIC=2
#REG_SET_FILE=/usr/share/phytec-gstreamer-examples/${REG_SET_FILE##*/}


echo "starting save_raw_image with format $COL_FMT"
echo "read $X_RES x $Y_RES and write to RAW-file"
echo "============================================="

save_raw_image -D $IPU1_CSI0_DEVICE -no_subdev -f $COL_FMT -res_x $X_RES -res_y $Y_RES -d $NUMBER_OF_PIC -n $CAMERA"_PixDepth_"$CAM_BW_FMT"_"
#save_raw_image -D $IPU1_CSI0_DEVICE -no_subdev -f $COL_FMT -res_x $X_RES -res_y $Y_RES -d $NUMBER_OF_PIC -r $REG_SET_FILE -n $CAMERA"_PixDepth_"$CAM_BW_FMT"_"
