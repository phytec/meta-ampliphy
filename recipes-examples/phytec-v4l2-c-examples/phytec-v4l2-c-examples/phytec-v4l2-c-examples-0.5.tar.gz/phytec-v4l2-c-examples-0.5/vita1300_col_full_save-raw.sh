#!/bin/sh

. /usr/share/phytec-gstreamer-examples/func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo "pixel depth"
echo "================="
echo "1 = 8-Bit"
echo "2 = 10-Bit (only for phyCAM-P)"
read PIX_DEPTH
echo "Your select = $PIX_DEPTH"
case $PIX_DEPTH in
  "1") CAM_COL_FMT="SRGGB8_1X8";;
  "2") CAM_COL_FMT="SRGGB10_1X10";;
  *) CAM_COL_FMT="SRGGB8_1X8";;
esac

echo ""
echo "configure IPU1_CSI0 (camera_0 port) with media_control"
echo "======================================================"

media-ctl -r
media-ctl -l ''$CAM_ENTITY_NUMBER'0->"ipu1_csi0_mux":1[1]'
media-ctl -l "'ipu1_csi0_mux':2->'ipu1_csi0':0[1]"
media-ctl -l "'ipu1_csi0':2->'ipu1_csi0 capture':0[1]"
#           Camera -> IPU1_CSI0_mux -> IPU1-CSI0 -> IPU1-CSI0 capture (/dev/videoX)   

v4l2-ctl -d $IPU1_CSI0_DEVICE -c subsampling=$SUBSAMPLING
# Note: Set subsampling is necessary before set resolution

media-ctl -V ''$CAM_ENTITY_NUMBER'0 [fmt:'$CAM_COL_FMT'/'$SENSOR_RES'('$OFFSET_SENSOR')/'$SENSOR_RES']'
media-ctl -V '"ipu1_csi0_mux":2 [fmt:'$CAM_COL_FMT'/'$SENSOR_RES']'
media-ctl -V '"ipu1_csi0":2 [fmt:'$CAM_COL_FMT'/'$SENSOR_RES']'

# Additional Settings
COL_FMT=${CAM_COL_FMT%%_*}
X_RES=${SENSOR_RES%%x*}
Y_RES=${SENSOR_RES##*x}
REG_SET_FILE=/usr/share/phytec-gstreamer-examples/${REG_SET_FILE##*/}


echo "starting save_raw_image with format $COL_FMT"
echo "read $X_RES x $Y_RES and write to RAW-file"
echo ""
echo "Note: Pixel are not remapped!"
echo "============================================="

save_raw_image -D $IPU1_CSI0_DEVICE -no_subdev -f $COL_FMT -res_x $X_RES -res_y $Y_RES -d $NUMBER_OF_PIC -n $CAMERA"_PixDepth_"$CAM_COL_FMT"_"
#save_raw_image -D $IPU1_CSI0_DEVICE -no_subdev -f $COL_FMT -res_x $X_RES -res_y $Y_RES -d $NUMBER_OF_PIC -r $REG_SET_FILE -n $CAMERA"_PixDepth_"$CAM_COL_FMT"_"
